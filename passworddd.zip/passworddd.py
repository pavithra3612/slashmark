import random
import string

def is_strong_password(password):
    """
    Checks if the given password meets the criteria of a strong password:
    - More than 6 characters long
    - Contains at least one uppercase letter
    - Contains at least one lowercase letter
    - Contains at least one digit
    - Contains at least one special character
    """
    if len(password) <= 6:
        return False
    
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(c in string.punctuation for c in password)
    
    return has_upper and has_lower and has_digit and has_special

def generate_password(length):
    """
    Generates a strong password with the specified length.
    The password will contain at least one uppercase letter, one lowercase letter, one digit, and one special symbol.

    :param length: Total length of the password (must be more than 6)
    :return: Generated password as a string
    """
    if length <= 6:
        raise ValueError("Password length must be more than 6 characters")

    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    numbers = string.digits
    special = string.punctuation

    # Ensure the password contains at least one of each required character type
    password = [
        random.choice(lower),
        random.choice(upper),
        random.choice(numbers),
        random.choice(special)
    ]

    # Fill the remaining length of the password
    all_characters = lower + upper + numbers + special
    password += [random.choice(all_characters) for _ in range(length - 4)]

    # Shuffle the password list to ensure randomness
    random.shuffle(password)

    # Convert the list to a string and return it
    return ''.join(password)

def main():
    print("Welcome to the Strong Password Generator!")
    min_length = 7

    # Get the number of passwords to generate
    while True:
        try:
            num_passwords = int(input("How many passwords do you want to generate: "))
            if num_passwords > 0:
                break
            else:
                print("Please enter a positive number.")
        except ValueError:
            print("Please enter a valid number.")

    for i in range(1, num_passwords + 1):
        print(f"\nGenerating Password #{i}")
        
        while True:
            user_password = input(f"Enter the password you want to provide for Password #{i} (or leave empty to generate one): ")
            if user_password:
                if is_strong_password(user_password):
                    print(f"Provided Password #{i} is strong and secure: {user_password}")
                    break
                else:
                    print("The provided password does not meet the security criteria. Please try again.")
            else:
                while True:
                    try:
                        length = int(input(f"Enter the total length of Password #{i} (must be more than {min_length - 1}): "))
                        if length >= min_length:
                            break
                        else:
                            print(f"Password length must be more than {min_length - 1}. Please try again.")
                    except ValueError:
                        print("Please enter a valid number.")
                
                # Generate the password
                try:
                    password = generate_password(length)
                    print(f"Generated Password #{i}: {password}")
                    break
                except ValueError as e:
                    print(f"Error: {e}")
                    return

if __name__ == "__main__":
    main()
