import requests

def send_message(message: str):
    url = "http://localhost:5005/webhooks/rest/webhook"
    payload = {
        "sender": "user",
        "message": message
    }
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error: {e}")
        return []

def main():
    print("Hello! I am your chatbot. Type 'exit' to end the conversation.")
    while True:
        message = input("You: ")
        if message.lower() == 'exit':
            break
        responses = send_message(message)
        if not responses:
            print("Bot: Sorry, I couldn't connect to the server. Please ensure the Rasa server is running.")
        for response in responses:
            print("Bot:", response.get("text"))

if __name__ == "__main__":
    main()
