import speech_recognition as sr
import pyttsx3
import pywhatkit
import wikipedia
import pywintypes
import datetime
import webbrowser

# Initialize the text-to-speech engine
engine = pyttsx3.init()

def speak(text):
    """Convert text to speech."""
    engine.say(text)
    engine.runAndWait()

def take_command():
    """Listen to the user's voice command and return it as text."""
    listener = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            print("Listening...")
            listener.adjust_for_ambient_noise(source)
            voice = listener.listen(source)
            command = listener.recognize_google(voice)
            command = command.lower()
            print(f"User said: {command}")
    except sr.UnknownValueError:
        speak("Sorry, I did not get that")
        return ""
    except sr.RequestError:
        speak("Sorry, my speech service is down")
        return ""
    return command

def play_song(song):
    """Play a song on YouTube."""
    speak(f"Playing {song}")
    pywhatkit.playonyt(song)

def search_wikipedia(query):
    """Search for a query on Wikipedia and speak the summary."""
    try:
        results = wikipedia.summary(query, sentences=2)
        speak(f"According to Wikipedia: {results}")
    except wikipedia.exceptions.DisambiguationError:
        speak("There are multiple results for this query, please be more specific.")
    except wikipedia.exceptions.PageError:
        speak("I couldn't find any information on that topic.")

def tell_time():
    """Tell the current time."""
    time = datetime.datetime.now().strftime('%I:%M %p')
    speak(f"The time is {time}")

def open_website(url):
    """Open a website."""
    if not url.startswith("http"):
        url = "https://" + url
    speak(f"Opening {url}")
    webbrowser.open(url)

def run_assistant():
    """Run the voice assistant."""
    command = take_command()
    if 'play' in command:
        song = command.replace('play', '').strip()
        play_song(song)
    elif 'time' in command:
        tell_time()
    elif 'who is' in command or 'what is' in command:
        search_query = command.replace('who is', '').replace('what is', '').strip()
        search_wikipedia(search_query)
    elif 'open' in command:
        website = command.replace('open', '').strip()
        open_website(website)
    else:
        speak("I didn't understand that command.")

if __name__ == "__main__":
    speak("How can I help you?")
    while True:
        run_assistant()
