class ToDoList:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        self.tasks.append({"task": task, "completed": False})
        print(f"Added task: '{task}'")

    def complete_task(self, task_index):
        if 0 <= task_index < len(self.tasks):
            self.tasks[task_index]["completed"] = True
            print(f"Completed task: '{self.tasks[task_index]['task']}'")
        else:
            print("Invalid task index")

    def remove_task(self, task_index):
        if 0 <= task_index < len(self.tasks):
            removed_task = self.tasks.pop(task_index)
            print(f"Removed task: '{removed_task['task']}'")
        else:
            print("Invalid task index")

    def show_tasks(self):
        if not self.tasks:
            print("No tasks in the to-do list")
            return
        for index, task in enumerate(self.tasks):
            status = "✓" if task["completed"] else "✗"
            print(f"{index}: {task['task']} [{status}]")

def main():
    todo_list = ToDoList()

    while True:
        print("\nTo-Do List Menu:")
        print("1. Add task")
        print("2. Complete task")
        print("3. Remove task")
        print("4. Show tasks")
        print("5. Exit")

        choice = input("Choose an option: ")

        if choice == '1':
            task = input("Enter the task: ")
            todo_list.add_task(task)
        elif choice == '2':
            todo_list.show_tasks()
            task_index = int(input("Enter the task number to complete: "))
            todo_list.complete_task(task_index)
        elif choice == '3':
            todo_list.show_tasks()
            task_index = int(input("Enter the task number to remove: "))
            todo_list.remove_task(task_index)
        elif choice == '4':
            todo_list.show_tasks()
        elif choice == '5':
            print("Exiting the to-do list application.")
            break
        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()
